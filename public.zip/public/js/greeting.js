document.addEventListener("DOMContentLoaded", function () {
  const greeting = "Hello from greeting.js!";
  console.log(greeting); // Display in the browser console
});
